//массивы
let array = ['Привет, ', 'мир', '!'];
console.log(array[0], array[1], array[2]);

let text = array[0] + array[1] + array[2];
console.log(text);

array.shift();
array.unshift('Пока, ')
console.log(array[0], array[1], array[2]);

//объекты
let obj = {a:1, b:2, c:3};
console.log(obj.c);

let weekDays = {
    1: 'Monday',
    2: 'Tuesday',
    3: 'Wednesday',
    4: 'Thursday',
    5: 'Friday',
    6: 'Saturday',
    7: 'Sunday'
}
console.log(weekDays[1]);

//циклы
let arr = [1, 2, 3, 4, 5]
for (let i = 0; i < arr.length; i++) {
    console.log(arr[i]); 
}

let arr2 = [2, 5, 9, 15, 0, 4]
for (let i = 0; i < arr2.length; i++) {
   if (arr2[i] > 3 && arr2[i] < 10) {
    console.log(arr2[i]);
   }
}


