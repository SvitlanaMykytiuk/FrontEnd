let years = prompt('Сколько Вам лет?')
let min = years*365*24*60
console.log(`Вам ${min} минут`);

let num = prompt('Введите число') 
let squareNum = num*num
console.log(`Квадрат числа ${squareNum}`);

let num1 = prompt('Введите первое число')
let num2 = prompt('Введите второе число')
let summ = Number(num1)+Number(num2)
console.log(`Сумма чисел ${summ}`); 
